# NEXT_TASK.md

## Vừa hoàn thành

Question Bank + Quiz Engine đầy đủ (migration 0009, Repository/Service/
Controller/routes). Đã kiểm chứng TOÀN BỘ vòng đời bằng HTTP thật: tạo câu
hỏi → xuất bản → tạo quiz → gán câu hỏi → xuất bản quiz → học sinh làm bài
(đáp án ẩn đúng cách) → nộp bài đúng (100%/đậu) → làm lại sai (0%/rớt) →
chặn đúng max_attempts ở lượt 3. Sửa 1 bug thật (trùng named parameter
`:creator`, cùng lớp lỗi đã gặp ở LessonRepository — đã quét lại toàn bộ
Repository bằng tokenizer, xác nhận sạch).

## Đang làm ngay bây giờ: Gamification (XP/Rank/Badge) — nối vào Quiz Engine vừa xong

Lý do ưu tiên: Quiz Engine vừa hoàn thành là nguồn sự kiện tự nhiên đầu tiên
cho Gamification (hoàn thành quiz → cộng XP). Schema Gamification đã có sẵn
từ đầu (`xp_transactions`, `levels`, `ranks`, `badges`, `achievements` chưa
tạo — cần kiểm tra lại migration nào đã có, có thể phải tạo mới). Đây là
tính năng "cảm giác được" rõ rệt nhất cho học sinh, và schema/event system
đã sẵn sàng (`EventDispatcher` đã có, chỉ cần thêm `QuizCompletedEvent` +
`AwardXpListener`).

Phạm vi cụ thể:
- Kiểm tra/tạo migration cho Gamification nếu chưa có (`xp_transactions`,
  `user_levels`, `ranks`, `badges`, `user_badges`, `learning_streaks`).
- `GamificationService`: `awardXp()`, tính rank theo XP, streak.
- `QuizCompletedEvent` (dispatch từ `QuizAttemptService::finish()`) +
  `AwardXpListener`.
- Hiển thị XP/Rank trên Student Dashboard đã có (`pages/dashboard/index.php`).
- **Test thật bằng HTTP** như đã làm ở Quiz Engine — môi trường PHP+MySQL
  vẫn dùng được (cần `service mysql start` + tạo lại `.env` mỗi lượt vì
  sandbox thỉnh thoảng tự reset).

## Không được làm trước Gamification

Forum/Chat/Blog (chưa bắt đầu) — Gamification cấp bách hơn vì đã có Quiz
Engine làm nguồn sự kiện, để lâu sẽ phải quay lại nối dây.

## Ghi chú cho lượt sau

Nếu môi trường test bị mất hoàn toàn, lệnh khôi phục nhanh:
```
service mysql start
# nếu fail: rm -f /var/run/mysqld/mysqld.sock.lock /var/lib/mysql/vm.pid && service mysql restart
cd /home/claude/hoahoc/project && cp .env.example .env
sed -i "s/DB_DATABASE=hoahoconga/DB_DATABASE=hoahoconga_test/;s/DB_USERNAME=hoahoconga_user/DB_USERNAME=hhcn_test/;s/DB_PASSWORD=/DB_PASSWORD=test_password_123/;s/APP_KEY=/APP_KEY=test_app_key_1234567890/;s/JWT_SECRET=/JWT_SECRET=test_jwt_secret_1234567890abcdef/;s/NODE_INTERNAL_SECRET=/NODE_INTERNAL_SECRET=test_internal_secret_abc/;s/APP_ENV=production/APP_ENV=local/;s/APP_DEBUG=false/APP_DEBUG=true/;s/SESSION_SECURE_COOKIE=true/SESSION_SECURE_COOKIE=false/" .env
composer install --no-interaction
```
D�� liệu test (users, courses, quiz) vẫn còn trong MySQL từ các lượt trước —
KHÔNG cần chạy lại migrate/seed trừ khi database thật sự bị xóa.
